from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

main_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="➕ Доход"),
            KeyboardButton(text="➖ Расход")
        ],
        [
            KeyboardButton(text="📊 Отчёт")
        ]
    ],
    resize_keyboard=True
)
